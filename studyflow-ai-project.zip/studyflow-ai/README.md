# StudyFlow AI

A small AI-powered study assistant built for the Frontend Internship Assignment. Paste notes or a topic, generate structured flashcards or a multiple-choice quiz, study interactively, and retry incorrect answers.

## Features

- Free-form notes/topic input
- Gemini API integration through an Express backend
- Structured JSON generation and Zod validation
- Interactive flashcards with flip, previous/next, and difficult-card marking
- Multiple-choice quizzes with explanations and score tracking
- Retest mode for incorrectly answered questions
- Loading, empty, retryable error, and malformed-response states
- Request cancellation on the frontend and request IDs to prevent stale results
- Responsive layout
- API key stays on the server

## Requirements

- Node.js 20 or newer
- npm
- A Gemini API key

## Setup

1. Install dependencies from the project root:

   ```bash
   npm install
   ```

2. Create `server/.env` by copying `.env.example` (or create it manually):

   ```env
   GEMINI_API_KEY=your_actual_key
   GEMINI_MODEL=gemini-2.5-flash
   PORT=3001
   CLIENT_ORIGIN=http://localhost:5173
   ```

   Never put the API key in `client/` or commit it to GitHub.

3. Start the frontend and backend:

   ```bash
   npm run dev
   ```

4. Open http://localhost:5173

## Useful commands

```bash
npm run dev       # frontend + backend development servers
npm run build     # production frontend build
npm test          # backend schema tests
```

The root `npm start` script runs the backend and Vite preview. Build first with `npm run build`.

## How it works

1. The React app posts the user's notes and requested mode to `/api/generate`.
2. Express validates the request, then calls Gemini using the server-only API key.
3. Gemini is asked for JSON output.
4. The backend parses and validates the result with Zod before returning it.
5. React renders validated data as flashcards or quiz questions, not as a chat transcript.

## Failure handling

- Invalid request: HTTP 400 with a readable message.
- Missing API key: HTTP 503 with setup guidance.
- Gemini/network/provider failure: HTTP 502 with a retryable error.
- Invalid JSON or incorrect response shape: HTTP 502; raw model text is not rendered.
- Empty user input: disabled controls and server-side validation.
- Slow requests: frontend timeout and abort support.
- New request: previous browser request is aborted; request IDs ensure only the latest request updates the UI.
- Empty validated collection: shown as an empty state.

## AI usage note

AI assistance was used to help scaffold the project, draft UI and validation logic, and prepare documentation. Review and understand the implementation before submitting it. The model generates study content, which may contain factual errors; users should verify important material.

## Known limitations

- No authentication, database, or saved sessions.
- Generated educational content is not guaranteed to be correct.
- Gemini model availability and quotas depend on the user's Google AI account.
- Quiz questions use four options and one correct option.
- The project does not stream partial results; it waits for a complete validated response.

## Time spent

Fill this in honestly before submission. The assignment recommends a maximum of approximately eight hours of actual work.

## Submission checklist

- [ ] Add your own API key to `server/.env`.
- [ ] Run through flashcard and quiz flows.
- [ ] Test an invalid key and a failed request.
- [ ] Check mobile layout.
- [ ] Update the AI usage note and actual time spent.
- [ ] Push meaningful commits to your own GitHub repository.
- [ ] Record a short demo.
- [ ] Be ready to explain the request flow, schema validation, state management, and stale-response protection.
