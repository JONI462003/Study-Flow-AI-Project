import "dotenv/config";
import express from "express";
import cors from "cors";
import { generateRequestSchema, validateModelData } from "./schemas.js";
import { generateWithGemini } from "./gemini.js";

const app = express();
const port = Number(process.env.PORT || 3001);
const allowedOrigin = process.env.CLIENT_ORIGIN || "http://localhost:5173";

app.use(cors({ origin: allowedOrigin }));
app.use(express.json({ limit: "40kb" }));

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "studyflow-api" }));

app.post("/api/generate", async (req, res) => {
  const request = generateRequestSchema.safeParse(req.body);
  if (!request.success) {
    return res.status(400).json({
      ok: false,
      error: "Please provide notes (3–12,000 characters) and choose a valid study mode."
    });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "your_gemini_api_key_here") {
    return res.status(503).json({
      ok: false,
      error: "Gemini API key is not configured. Add GEMINI_API_KEY to server/.env and restart the server."
    });
  }

  try {
    const modelData = await generateWithGemini({
      ...request.data,
      apiKey,
      model: process.env.GEMINI_MODEL || "gemini-2.5-flash"
    });
    const validated = validateModelData(modelData, request.data.mode);
    return res.json({ ok: true, data: validated });
  } catch (error) {
    console.error("[generate]", error.message);
    const schemaFailure = error.name === "ZodError";
    const message = schemaFailure
      ? "The AI response did not match the required study format. Please retry with clearer or more detailed notes."
      : error.message.includes("malformed JSON") || error.message.includes("empty response")
        ? error.message
        : "The AI service could not complete your request. Check your connection and API quota, then retry.";
    return res.status(502).json({ ok: false, error: message });
  }
});

app.use((error, _req, res, _next) => {
  if (error instanceof SyntaxError && "body" in error) {
    return res.status(400).json({ ok: false, error: "Request body must be valid JSON." });
  }
  console.error("[server]", error);
  return res.status(500).json({ ok: false, error: "Unexpected server error." });
});

app.listen(port, () => {
  console.log(`StudyFlow API running at http://localhost:${port}`);
});
