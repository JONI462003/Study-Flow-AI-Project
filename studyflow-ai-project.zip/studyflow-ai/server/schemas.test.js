import test from "node:test";
import assert from "node:assert/strict";
import { validateModelData, generateRequestSchema } from "./schemas.js";

test("accepts a valid flashcard response", () => {
  const data = {
    title: "Water Cycle",
    cards: [{ id: 1, question: "What is evaporation?", answer: "Liquid water becomes vapor." }]
  };
  assert.equal(validateModelData(data, "flashcards").cards.length, 1);
});

test("rejects a flashcard with a missing answer", () => {
  const data = { title: "Topic", cards: [{ id: 1, question: "Question?" }] };
  assert.throws(() => validateModelData(data, "flashcards"));
});

test("rejects a quiz with an invalid answer index", () => {
  const data = {
    title: "Quiz",
    questions: [{
      id: 1, question: "Question?", options: ["A", "B", "C", "D"],
      correctAnswer: 4, explanation: "Because."
    }]
  };
  assert.throws(() => validateModelData(data, "quiz"));
});

test("rejects empty notes and unknown modes", () => {
  assert.equal(generateRequestSchema.safeParse({ text: " ", mode: "quiz" }).success, false);
  assert.equal(generateRequestSchema.safeParse({ text: "Some notes", mode: "chat" }).success, false);
});

test("accepts a valid quiz response", () => {
  const data = {
    title: "Quiz",
    questions: [{
      id: 1, question: "What is 2 + 2?", options: ["1", "2", "4", "5"],
      correctAnswer: 2, explanation: "Two plus two equals four."
    }]
  };
  assert.equal(validateModelData(data, "quiz").questions[0].correctAnswer, 2);
});
