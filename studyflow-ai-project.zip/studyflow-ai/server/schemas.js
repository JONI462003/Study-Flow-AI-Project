import { z } from "zod";

const nonEmptyText = z.string().trim().min(1).max(500);
const base = {
  title: z.string().trim().min(1).max(120),
  description: z.string().trim().max(300).optional().default("")
};

export const flashcardResponseSchema = z.object({
  ...base,
  cards: z.array(z.object({
    id: z.union([z.string().min(1), z.number().int()]),
    question: nonEmptyText,
    answer: nonEmptyText
  }).strict()).min(1).max(30)
}).strict();

export const quizResponseSchema = z.object({
  ...base,
  questions: z.array(z.object({
    id: z.union([z.string().min(1), z.number().int()]),
    question: nonEmptyText,
    options: z.array(nonEmptyText).length(4),
    correctAnswer: z.number().int().min(0).max(3),
    explanation: nonEmptyText
  }).strict()).min(1).max(20)
}).strict();

export const generateRequestSchema = z.object({
  text: z.string().trim().min(3).max(12000),
  mode: z.enum(["flashcards", "quiz"])
}).strict();

export function validateModelData(data, mode) {
  return mode === "flashcards"
    ? flashcardResponseSchema.parse(data)
    : quizResponseSchema.parse(data);
}
