function buildPrompt(text, mode) {
  if (mode === "flashcards") {
    return `Create a useful study set from the source notes below. Return only a JSON object with this exact shape:
{"title":"short topic title","description":"one short sentence","cards":[{"id":1,"question":"clear question","answer":"accurate concise answer"}]}
Requirements: create 6 to 10 cards when the source supports it; every card must test a meaningful concept; do not invent facts absent from the notes; IDs must be unique; keep question and answer non-empty. If the notes are limited, create fewer high-quality cards rather than inventing information.
SOURCE NOTES:
${text}`;
  }
  return `Create a multiple-choice quiz from the source notes below. Return only a JSON object with this exact shape:
{"title":"short quiz title","description":"one short sentence","questions":[{"id":1,"question":"clear question","options":["option A","option B","option C","option D"],"correctAnswer":0,"explanation":"brief explanation grounded in the notes"}]}
Requirements: create 5 to 8 questions when the source supports it; exactly four distinct options per question; correctAnswer is a zero-based integer from 0 to 3; exactly one option is correct; IDs must be unique; avoid trick questions; do not invent facts absent from the notes. If the notes are limited, create fewer high-quality questions rather than inventing information.
SOURCE NOTES:
${text}`;
}

export async function generateWithGemini({ text, mode, apiKey, model }) {
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`;
  const response = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ role: "user", parts: [{ text: buildPrompt(text, mode) }] }],
      generationConfig: {
        responseMimeType: "application/json",
        temperature: 0.4,
        maxOutputTokens: 5000
      }
    }),
    signal: AbortSignal.timeout(40_000)
  });

  const payload = await response.json().catch(() => null);
  if (!response.ok) {
    const providerMessage = payload?.error?.message;
    throw new Error(providerMessage || `Gemini request failed with status ${response.status}`);
  }

  const output = payload?.candidates?.[0]?.content?.parts
    ?.map((part) => part.text || "")
    .join("")
    .trim();

  if (!output) throw new Error("The AI returned an empty response.");
  try {
    return JSON.parse(output);
  } catch {
    throw new Error("The AI returned malformed JSON. Please retry or use more specific notes.");
  }
}
