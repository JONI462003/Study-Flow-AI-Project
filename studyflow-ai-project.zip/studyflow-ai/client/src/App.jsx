import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft, ArrowRight, BookOpen, Brain, Check, CheckCircle2, ChevronDown,
  CircleHelp, Clock3, RotateCcw, Sparkles, X, Zap
} from "lucide-react";
import { generateStudySet } from "./api.js";

const SAMPLE_NOTES = `The water cycle describes how water moves around Earth.
Evaporation happens when the sun heats liquid water and turns it into water vapor.
Condensation occurs when water vapor cools and forms tiny liquid droplets, creating clouds.
Precipitation happens when water droplets become heavy and fall as rain, snow, sleet, or hail.
Collection is when water gathers in oceans, lakes, rivers, and underground.`;

function App() {
  const [notes, setNotes] = useState("");
  const [mode, setMode] = useState("flashcards");
  const [studySet, setStudySet] = useState(null);
  const [activeTab, setActiveTab] = useState("flashcards");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [cardIndex, setCardIndex] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [difficult, setDifficult] = useState([]);
  const [quizAnswers, setQuizAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [retestOnly, setRetestOnly] = useState(false);
  const [retestIds, setRetestIds] = useState([]);
  const [requestCount, setRequestCount] = useState(0);
  const abortRef = useRef(null);
  const latestRequestRef = useRef(0);

  useEffect(() => () => abortRef.current?.abort(), []);

  const cards = studySet?.cards ?? [];
  const allQuestions = studySet?.questions ?? [];
  const questions = retestOnly
    ? allQuestions.filter((q) => retestIds.includes(q.id))
    : allQuestions;
  const wrongIds = submitted
    ? questions.filter((q) => quizAnswers[q.id] !== q.correctAnswer).map((q) => q.id)
    : [];
  const score = questions.filter((q) => quizAnswers[q.id] === q.correctAnswer).length;
  const currentCard = cards[cardIndex];

  async function handleGenerate(nextMode = mode) {
    if (!notes.trim()) {
      setError("Add some notes or a topic first.");
      return;
    }
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;
    const requestId = ++latestRequestRef.current;
    setRequestCount((count) => count + 1);
    setLoading(true);
    setError("");
    setNotice("");
    setMode(nextMode);
    setActiveTab(nextMode);
    setStudySet(null);
    setCardIndex(0);
    setFlipped(false);
    setDifficult([]);
    setQuizAnswers({});
    setSubmitted(false);
    setRetestOnly(false);
    setRetestIds([]);

    try {
      const data = await generateStudySet({ text: notes.trim(), mode: nextMode, signal: controller.signal });
      if (requestId !== latestRequestRef.current) return;
      setStudySet(data);
      if ((data.cards?.length ?? data.questions?.length ?? 0) === 0) {
        setNotice("The AI returned no study items. Try adding more detailed notes.");
      }
    } catch (err) {
      if (err.name !== "AbortError" && requestId === latestRequestRef.current) {
        setError(err.message || "Something went wrong. Please try again.");
      }
    } finally {
      if (requestId === latestRequestRef.current) setLoading(false);
    }
  }

  function cancelGeneration() {
    latestRequestRef.current += 1;
    abortRef.current?.abort();
    setLoading(false);
    setNotice("Generation cancelled.");
  }

  function changeCard(direction) {
    setCardIndex((index) => Math.min(cards.length - 1, Math.max(0, index + direction)));
    setFlipped(false);
  }

  function startRetest() {
    setRetestIds(wrongIds);
    setRetestOnly(true);
    setQuizAnswers({});
    setSubmitted(false);
    setActiveTab("quiz");
  }

  function resetQuiz() {
    setQuizAnswers({});
    setSubmitted(false);
    setRetestOnly(false);
    setRetestIds([]);
  }

  const hasResult = Boolean(studySet);
  const itemCount = mode === "flashcards" ? cards.length : allQuestions.length;

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#" onClick={(e) => e.preventDefault()}>
          <span className="brand-mark"><Brain size={21} /></span>
          <span>studyflow<span className="brand-ai">.ai</span></span>
        </a>
        <div className="topbar-right">
          <span className="topbar-pill"><span className="status-dot" /> AI study workspace</span>
          <div className="avatar">S</div>
        </div>
      </header>

      <main className="main-content">
        <section className="hero">
          <div className="eyebrow"><Sparkles size={14} /> YOUR PERSONAL AI STUDY PARTNER</div>
          <h1>Learn anything.<br /><span>Remember everything.</span></h1>
          <p className="hero-copy">Turn your notes into focused flashcards and quick quizzes. Less rereading, more understanding.</p>
        </section>

        <section className="input-panel">
          <div className="panel-heading">
            <div>
              <div className="section-kicker">STEP 01</div>
              <h2>What are you learning today?</h2>
            </div>
            <button className="text-button" onClick={() => setNotes(SAMPLE_NOTES)}>Try sample notes <ArrowRight size={14} /></button>
          </div>
          <label className="sr-only" htmlFor="study-notes">Your notes or topic</label>
          <textarea
            id="study-notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Paste your class notes, a chapter summary, or simply type a topic you want to learn..."
            maxLength={12000}
            rows={6}
          />
          <div className="input-footer">
            <span>{notes.length.toLocaleString()} / 12,000 characters</span>
            <span>Tip: detailed notes create better study material</span>
          </div>
          <div className="generate-row">
            <button className={`generate-button ${loading ? "is-loading" : ""}`} disabled={loading || !notes.trim()} onClick={() => handleGenerate("flashcards")}>
              <BookOpen size={17} /> Generate flashcards <span className="button-arrow">→</span>
            </button>
            <button className="secondary-button" disabled={loading || !notes.trim()} onClick={() => handleGenerate("quiz")}>
              <Zap size={16} /> Create a quiz
            </button>
            {loading && <button className="cancel-button" onClick={cancelGeneration}>Cancel</button>}
          </div>
          {error && (
            <div className="alert alert-error" role="alert">
              <X size={18} /><div><strong>Couldn't generate your study set</strong><p>{error}</p></div>
              <button className="alert-action" onClick={() => handleGenerate(mode)}>Retry</button>
            </div>
          )}
          {notice && <div className="alert alert-info" role="status"><CircleHelp size={17} />{notice}</div>}
        </section>

        {loading && (
          <section className="loading-panel" aria-live="polite">
            <div className="loader-orbit"><Sparkles size={22} /></div>
            <div><strong>Building your study set</strong><p>Reading your notes and creating {mode === "flashcards" ? "flashcards" : "quiz questions"}...</p></div>
            <div className="loading-track"><span /></div>
          </section>
        )}

        {!hasResult && !loading && !error && (
          <section className="empty-state">
            <div className="empty-illustration"><BookOpen size={28} /><Sparkles className="empty-spark" size={17} /></div>
            <h3>Your next study session starts here</h3>
            <p>Add notes above, then choose flashcards or a quiz. Your interactive study set will appear here.</p>
            <div className="feature-chips"><span><CheckCircle2 size={14} /> Active recall</span><span><Clock3 size={14} /> Self-paced</span><span><Brain size={14} /> AI generated</span></div>
          </section>
        )}

        {hasResult && (
          <section className="results-section">
            <div className="results-heading">
              <div>
                <div className="section-kicker">STEP 02 · YOUR STUDY SET</div>
                <h2>{studySet.title}</h2>
                <p>{studySet.description || "Your personalized learning material is ready."}</p>
              </div>
              <button className="icon-button" title="Generate a new set" onClick={() => { setStudySet(null); setError(""); }}><RotateCcw size={17} /></button>
            </div>

            <div className="tabs" role="tablist" aria-label="Study modes">
              <button role="tab" aria-selected={activeTab === "flashcards"} className={activeTab === "flashcards" ? "active" : ""} onClick={() => setActiveTab("flashcards")} disabled={!cards.length}><BookOpen size={16} /> Flashcards <span>{cards.length}</span></button>
              <button role="tab" aria-selected={activeTab === "quiz"} className={activeTab === "quiz" ? "active" : ""} onClick={() => setActiveTab("quiz")} disabled={!allQuestions.length}><CircleHelp size={16} /> Quiz <span>{allQuestions.length}</span></button>
            </div>

            {activeTab === "flashcards" && cards.length > 0 && (
              <div className="study-area">
                <div className="study-toolbar">
                  <span className="counter">CARD <strong>{cardIndex + 1}</strong> OF <strong>{cards.length}</strong></span>
                  <span className="toolbar-hint">Click the card to reveal the answer</span>
                </div>
                <button className={`flashcard ${flipped ? "flipped" : ""}`} onClick={() => setFlipped((value) => !value)} aria-label={flipped ? "Show question" : "Reveal answer"}>
                  <span className="card-label">{flipped ? "ANSWER" : "QUESTION"}</span>
                  <span className="card-content">{flipped ? currentCard.answer : currentCard.question}</span>
                  <span className="flip-hint"><RotateCcw size={14} /> Click to flip</span>
                </button>
                <div className="progress-track"><span style={{ width: `${((cardIndex + 1) / cards.length) * 100}%` }} /></div>
                <div className="card-controls">
                  <button className="secondary-button" disabled={cardIndex === 0} onClick={() => changeCard(-1)}><ArrowLeft size={16} /> Previous</button>
                  <button className={`difficult-button ${difficult.includes(currentCard.id) ? "marked" : ""}`} onClick={() => setDifficult((old) => old.includes(currentCard.id) ? old.filter((id) => id !== currentCard.id) : [...old, currentCard.id])}>
                    {difficult.includes(currentCard.id) ? <Check size={15} /> : <Brain size={15} />}
                    {difficult.includes(currentCard.id) ? "Marked difficult" : "Mark difficult"}
                  </button>
                  <button className="primary-button" disabled={cardIndex === cards.length - 1} onClick={() => changeCard(1)}>Next <ArrowRight size={16} /></button>
                </div>
                {difficult.length > 0 && <p className="small-note">{difficult.length} card{difficult.length === 1 ? "" : "s"} marked for extra practice.</p>}
              </div>
            )}

            {activeTab === "quiz" && allQuestions.length > 0 && (
              <div className="quiz-area">
                {retestOnly && <div className="retest-banner"><RotateCcw size={15} /> Retest mode · practicing questions you missed</div>}
                {!submitted ? (
                  <>
                    <div className="quiz-topline"><span>{questions.length} question{questions.length === 1 ? "" : "s"}</span><span>{Object.keys(quizAnswers).length} answered</span></div>
                    {questions.length === 0 ? (
                      <div className="empty-quiz"><CheckCircle2 size={28} /><h3>Nothing to retest</h3><p>You haven't missed any questions. Great work!</p><button className="primary-button" onClick={() => setRetestOnly(false)}>Back to all questions</button></div>
                    ) : questions.map((q, index) => (
                      <article className="question-card" key={q.id}>
                        <div className="question-number">QUESTION {index + 1} <span>·</span> {retestOnly ? "RETEST" : `OF ${questions.length}`}</div>
                        <h3>{q.question}</h3>
                        <div className="options-list">
                          {q.options.map((option, optionIndex) => {
                            const selected = quizAnswers[q.id] === optionIndex;
                            return (
                              <button key={`${q.id}-${optionIndex}`} className={`option ${selected ? "selected" : ""}`} onClick={() => setQuizAnswers((old) => ({ ...old, [q.id]: optionIndex }))}>
                                <span className="option-letter">{String.fromCharCode(65 + optionIndex)}</span>{option}
                                {selected && <Check size={16} className="option-check" />}
                              </button>
                            );
                          })}
                        </div>
                      </article>
                    ))}
                    {questions.length > 0 && <button className="generate-button submit-quiz" disabled={Object.keys(quizAnswers).filter((id) => questions.some((q) => q.id === id)).length !== questions.length} onClick={() => setSubmitted(true)}>Submit answers <ArrowRight size={16} /></button>}
                  </>
                ) : (
                  <div className="score-panel">
                    <div className="score-icon"><CheckCircle2 size={29} /></div>
                    <div className="section-kicker">QUIZ COMPLETE</div>
                    <div className="score-number">{score}<span> / {questions.length}</span></div>
                    <h3>{score === allQuestions.length ? "Perfect score!" : score >= allQuestions.length / 2 ? "Good progress!" : "Keep practicing!"}</h3>
                    <p>You answered {score} of {questions.length} questions correctly.</p>
                    <div className="answer-review">
                      {questions.map((q) => {
                        const correct = quizAnswers[q.id] === q.correctAnswer;
                        return <div className={`review-item ${correct ? "correct" : "incorrect"}`} key={q.id}>
                          <div className="review-heading">{correct ? <CheckCircle2 size={16} /> : <X size={16} />}<strong>{q.question}</strong></div>
                          <p>{correct ? "Correct" : `Correct answer: ${q.options[q.correctAnswer]}`}</p>
                          <small>{q.explanation}</small>
                        </div>;
                      })}
                    </div>
                    <div className="score-actions">
                      {wrongIds.length > 0 && <button className="generate-button" onClick={startRetest}><RotateCcw size={16} /> Retest {wrongIds.length} missed</button>}
                      <button className="secondary-button" onClick={resetQuiz}>Try all questions again</button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </section>
        )}
        <footer className="footer"><span>Made for curious minds.</span><span><Sparkles size={13} /> StudyFlow AI</span></footer>
      </main>
    </div>
  );
}

export default App;
