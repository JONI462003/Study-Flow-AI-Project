const REQUEST_TIMEOUT_MS = 45_000;

export async function generateStudySet({ text, mode, signal }) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(new Error("Request timed out")), REQUEST_TIMEOUT_MS);

  const abortFromCaller = () => controller.abort(signal?.reason);
  if (signal?.aborted) abortFromCaller();
  signal?.addEventListener("abort", abortFromCaller, { once: true });

  try {
    const response = await fetch("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, mode }),
      signal: controller.signal
    });

    const payload = await response.json().catch(() => null);
    if (!response.ok) {
      throw new Error(payload?.error || `Request failed (${response.status})`);
    }
    if (!payload || payload.ok !== true || !payload.data) {
      throw new Error("The server returned an unexpected response. Please try again.");
    }
    return payload.data;
  } catch (error) {
    if (controller.signal.aborted) {
      if (signal?.aborted) throw new DOMException("Request cancelled", "AbortError");
      throw new Error("The request took too long. Please try again.");
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
    signal?.removeEventListener("abort", abortFromCaller);
  }
}
